x = 1:10;
squared_x = x .^ 2;
fprintf('Original vector x: ');
disp(x);
fprintf('Squared elements: ');
disp(squared_x);
