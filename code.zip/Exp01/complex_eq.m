x=2;
y=4;
z=6;
x^2+y^2+z^2+sqrt(x*y)
