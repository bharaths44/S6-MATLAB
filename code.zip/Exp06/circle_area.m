function area = area(radius)
    % Computes the area of a circle given its radius
    area = pi * radius^2; % Area formula: πr^2
end


radius = input('Enter the radius of the circle: ');
if radius < 0
    fprintf('Error: Radius cannot be negative.\n');
else
    final_area = area(radius);
    fprintf('The area of the circle with radius %.2f is: %.2f\n', radius, final_area);
end
