A = [1, 2, 3];
B = [4, 5, 6];
dot_product = dot(A, B);
cross_product = cross(A, B);
fprintf('Dot Product of A and B: %d\n', dot_product);
fprintf('Cross Product of A and B: [%d, %d, %d]\n', cross_product);
